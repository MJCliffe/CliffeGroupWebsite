Scripts for creating PASCal Indicatrix Plot

Two scripts are included, for Python (recommended) and Gnuplot. Run using

python indicatrix.py A B C

where A, B, C are the principal values of the thermal expansivity/compressibility.
Matplotlib and numpy are required python libraries.

Matt Cliffe (2021)
