import numpy as np
import sys
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt

theta, phi = np.linspace(0, 2 * np.pi, 50), np.linspace(0, np.pi, 50)
THETA, PHI = np.meshgrid(theta, phi)

A = float(sys.argv[1])
B = float(sys.argv[2])
C = float(sys.argv[3])
max = max(abs(A),abs(B),abs(C))

R = A*(np.sin(THETA)*np.cos(PHI))**2+ B*(np.sin(THETA)*np.sin(PHI))**2+C*(np.cos(THETA)**2)
Pos = (R+np.abs(R))/2
Neg = (R-np.abs(R))/2
R = Pos
X = R * np.sin(THETA) * np.cos(PHI)
Y = R * np.sin(THETA) * np.sin(PHI)
Z = R * np.cos(THETA)
fig = plt.figure()
ax = fig.add_subplot(1,1,1, projection='3d')

plot = ax.plot_wireframe(
    X, Y, Z, rstride=1,
    cstride=1, antialiased=True, alpha=0.5,color='red')

R = Neg
X = R * np.sin(THETA) * np.cos(PHI)
Y = R * np.sin(THETA) * np.sin(PHI)
Z = R * np.cos(THETA)
plot = ax.plot_wireframe(
    X, Y, Z, rstride=1,
    cstride=1, antialiased=True, alpha=0.5,color='blue')

ax.set_xlim3d([-3,3])
ax.set_ylim3d([-3,3])
ax.set_zlim3d([-3,3])

plt.savefig('PASCal.png')
plt.show()


#plot = ax.plot_surface(
#    X, Y, Z, rstride=1, cstride=1,
#    linewidth=0, antialiased=True, alpha=0.5)
