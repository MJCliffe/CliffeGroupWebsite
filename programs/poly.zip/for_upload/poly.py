from pymol.cgo import *
from pymol import cmd


def poly(sele,cr=1.0, cg=0.4, cb=0.8,ca =1.0,cond='all', resize=1.0,offset=0.0001):
#EXAMPLE
#poly('elem Si',0.1,0.2,0.6,0.5,'elem O',0.5)
	import scipy.spatial #needs to be at least v0.10
	import numpy as np
	np.random.seed()
	cr = abs(float(cr)) #red
	cg = abs(float(cg)) #green
	cb = abs(float(cb)) #blue
	ca = abs(float(ca)) #alpha
	atoms = cmd.get_model(sele) #sele is atoms to draw polyhedra around

	for at in atoms.atom:
		cmd.select ('neigh', '('+cond+') and (nbr. '+sele+') and (nbr. index '+str(at.index)+')') #cond is the filter for the neighbours
		
		points = np.array( cmd.get_model('neigh').get_coord_list() )
		cent = np.sum(points, axis=0)/len(points)
		print'Atom with index:',str(at.index), 'has',str(len(points)),'neighbours'
		if(len(points)<1):
			print 'Atom with index:',str(at.index),'has no valid neighbours'
			continue
		if(len(points)<3):
			print 'Atom with index:',str(at.index),'has too few valid neighbours (',len(points),')'
			continue
			
		points = resize*points+(1-resize)*cent

		if(len(points)==3): #i.e. just a triangle
			norm = np.cross(points[1]-points[0], points[2]-points[0])
			
			
			obj=[];
			#the alpha is a matter of choice here - the do you want each triangle to block as much light as another triangle in a polyhedron
			#or do you want the triangle polyhedron to block as much light as any other polyhedron? currently set as the latter
			obj.extend([BEGIN,TRIANGLES, ALPHA,ca, COLOR, cr, cg, cb,NORMAL,norm[0],norm[1],norm[2]])
			for i in range(3):
				obj.append( VERTEX )
				obj.extend(points[i])
			obj.append(END)	
			 
			norm*=-1 #this is the other face of the triangle, to keep it shiny
			obj.extend([BEGIN,TRIANGLES, ALPHA,ca, COLOR, cr, cg, cb,NORMAL,norm[0],norm[1],norm[2]])

			points = points+norm*0.0001 #this is so the two faces don't directly overlap
			for i in range(3):
				obj.append( VERTEX )
				obj.extend(points[i])
			obj.append(END)	
					
			cName = cmd.get_unused_name("poly_")
			cmd.load_cgo( obj, cName )
			cmd.reset()
			continue
		max_pts=np.max(points)
		min_pts=np.min(points)

		points = (points-min_pts)/(max_pts-min_pts)+(2*np.random.rand(*points.shape)-1)*0.001 #this is so the two sets of points aren't coplanar

		tri = scipy.spatial.Delaunay(points)# qhul_options seemingly not implemented but QJ gives equivalent jitter
		hull =  tri.convex_hull
		points = points*(max_pts-min_pts)+min_pts

		obj=[];
		
			
		for sx in hull:
			#This calculates the normal thru a cross product and then corrects the 
			# direction by calculating the direction from the central atom to the face 
			#this should work for convex polyhedra  as r.n should always be +ve.

			norm = np.cross(points[sx[1]]-points[sx[0]], points[sx[2]]-points[sx[0]]) 
			norm_check = np.sum([points[sx[i]] for i in range(3)], axis=0)/3-cent
			norm*=np.sum(norm*norm_check)
			obj.extend([BEGIN,TRIANGLES, ALPHA,ca, COLOR, cr, cg, cb,NORMAL,norm[0],norm[1],norm[2]])
			for i in range(3):
				points[sx[i]] = points[sx[i]]+norm*offset #this is so the two faces don't directly overlap 
				obj.append( VERTEX )
				obj.extend(points[sx[i]])
			obj.append(END)
			
			norm*=-1 #this is the other face of the triangle, to keep it shiny
			obj.extend([BEGIN,TRIANGLES, ALPHA,ca, COLOR, cr, cg, cb,NORMAL,norm[0],norm[1],norm[2]])
			for i in range(3):
				points[sx[i]] = points[sx[i]]+norm*2*offset #this is so the two faces don't directly overlap
				obj.append( VERTEX )
				obj.extend(points[sx[i]])
			obj.append(END)
			
		cName = cmd.get_unused_name("poly_")
		cmd.load_cgo( obj, cName )
		cmd.reset()
		
cmd.extend( "poly", poly)
