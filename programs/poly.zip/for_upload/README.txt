###INSTRUCTIONS###
Save poly.py to a convenient location (e.g. ~/PymolScripts/poly.py).
Open your structure (.pdb etc) as usual.
Load the script using the run command (you only need to do this once per session):
    run ~/Documents/PymolScripts/poly.py

Run the script using the poly command

poly(sele1,r,g,b,alpha,sele2,rescale,offset)

sele1 = atoms to draw selection round
r g b = colour between 0 and 1
alpha = transparency between 0 and 1 (1 opaque, 0 transparent)
sele2 = restrictions on which bonded atoms are included in the polyhedron
rescale = factor by which to rescale the polyhedron (between 0 and 1: 1 full size, 0 absent)
offset = a parameter that defines the offset of the triangular faces of the polyhedron from the centre. this is primarily using to avoid the issues seen with flat objects (see below).

Example:
poly('elem Si',0.4,0.4,0.9,0.8,'elem O')
will draw polyhedra round silicon, with partially transparent blue polyhedra only including bonded O atoms.

poly('elem Si') works, with the default colour being pink.
poly ('elem Si') will not work.

poly should not crash if it is supplied with polyhedra containing < 4 points. For 3 points it will draw a triangle, and for fewer points it will issue a warning but continue.

###NOTES###
The new polyhedra are cgo objects named sequentially from poly_01. To delete them you can use the command 
    delete poly_*
As cgo objects they won't rotate with the structure when using the ‘rotate’ command.
There are occasionally drawing issues with flat objects, as the triangulation used may cause overlaps between the back and the front of objects, leading to Moire patterns forming. If you are seeing this, just increase the offset (default is 0.0001). If the offset is too large, there will be visible gaps between the faces of the polyhedron. 

The cgo objects and transparency only display properly after ray tracing.

Any bugs or queries please contact mjc222@cam.ac.uk